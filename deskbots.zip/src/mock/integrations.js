export default [
  {
    id: 1,
    nome: "Service Now",
    descricao: "Integração com o Service Now",
    status: "Disponível"
  },
  {
    id: 2,
    nome: "Jira",
    descricao: "Integração com o Jira",
    status: "Disponível"
  },
  {
    id: 3,
    nome: "Zendesk",
    descricao: "Integração com o Zendesk",
    status: "Indisponível"
  },
  {
    id: 4,
    nome: "Freshdesk",
    descricao: "Integração com o Freshdesk",
    status: "Disponível"
  },
  {
    id: 5,
    nome: "Salesforce",
    descricao: "Integração com o Salesforce",
    status: "Indisponível"
  },
  {
    id: 6,
    nome: "WhatsApp",
    descricao: "Integração com o WhatsApp",
    status: "Indisponível"
  }
]