export default [
  {
    "id": 1,
    "ativo": true,
    "nome": "Astro",
    "descricao": "Assistente responsável por gerar as TAGS do chamado",
    "imagem": "https://api.dicebear.com/9.x/bottts/svg?seed=Charlie"
  },

  {
    "id": 2,
    "ativo": true,
    "nome": "C-3PO",
    "descricao": "Assistente responsável por definir a PRIORIDADE do chamado",
    "imagem": "https://api.dicebear.com/9.x/bottts/svg?seed=Patches"
  },

  {
    "id": 3,
    "ativo": true,
    "nome": "R2-D2",
    "descricao": "Assistente responsável por definir o RESPONSÁVEL do chamado",
    "imagem": "https://api.dicebear.com/9.x/bottts-neutral/svg?seed=Spooky&flip=true&backgroundColor=3949ab,d1d4f9&backgroundType=solid,gradientLinear&backgroundRotation=360,-360,-330,-320&eyes=sensor&mouth=diagram"
  },

  {
    "id": 4,
    "ativo": true,
    "nome": "Baymax",
    "descricao": "Assistente responsável por definir o TIPO do chamado",
    "imagem": "https://api.dicebear.com/9.x/bottts/svg?seed=Sammy"
  },

  {
    "id": 5,
    "ativo": true,
    "nome": "WALL-E",
    "descricao": "Assistente responsável por definir o NÍVEL do chamado",
    "imagem": "https://api.dicebear.com/9.x/bottts-neutral/svg?seed=Harley"
  },

  {
    "id": 6,
    "ativo": true,
    "nome": "EVA",
    "descricao": "Assistente responsável por sugerir uma SOLUÇÃO para chamado",
    "imagem": "https://api.dicebear.com/9.x/bottts-neutral/svg?seed=Boots&eyes=eva&mouth=smile01"
  },

  {
    "id": 7,
    "ativo": true,
    "nome": "Ultron",
    "descricao": "Assistente responsável por documentar INSTRUÇÕES DE TRABALHO quando necessário",
    "imagem": "https://api.dicebear.com/9.x/bottts/svg?seed=Fluffy"
  },

  {
    "id": 8,
    "ativo": true,
    "nome": "Jarvis",
    "descricao": "Assistente responsável por coletar feedbacks e medir a SATISFAÇÃO do cliente",
    "imagem": "https://api.dicebear.com/9.x/bottts/svg?seed=Snickers"
  }
]